﻿using CapstoneEcom.Models;

namespace CapstoneEcom.Services
{
    public interface IDataAccess
    {
        public List<ProductCategory> GetProductCategories();
        public IList<User> GetUser();
        public ProductCategory GetProductCategory(int id);
        public offer GetOffer(int id);
        public List<product> GetProducts(string category, string subcategory, int count);
        public product GetProduct(int id);
        public bool InsertUser(User user);
        public string IsUserPresent(string email, string password);
        public void InsertReview(Review review);
        public List<Review> GetProductReviews(int productId);
        public User GetUser(int id);
        public bool InsertCartItem(int userId, int productId);
        public cart GetActiveCartOfUser(int userid);
        public cart GetCart(int cartid);
        public List<cart> GetAllPreviousCartsOfUser(int userid);
        public List<PaymentMethods> GetPaymentMethods();
        public int InsertPayment(Payment payment);
        public int InsertOrder(Order order);
        public void InsertNewProduct(product product);
        public bool DeleteProduct(int productid);
    }
}
