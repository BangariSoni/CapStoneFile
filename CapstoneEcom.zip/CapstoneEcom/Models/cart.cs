﻿

namespace CapstoneEcom.Models
{
    public class cart
    {
       
        public int Id { get; set; }
        public User User { get; set; } = new User();
        public List<cartItem> CartItems { get; set; } = new();
        public bool Ordered { get; set; }
        public string OrderedOn { get; set; } = string.Empty;
    }
}
