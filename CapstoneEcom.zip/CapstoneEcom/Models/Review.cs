﻿

namespace CapstoneEcom.Models
{
    public class Review
    {
      
        public int Id { get; set; }
        public User User { get; set; } = new User();
        public product Product { get; set; } = new product();
        public string Value { get; set; } = string.Empty;
        public string CreatedAt { get; set; } = string.Empty;
    }
}
