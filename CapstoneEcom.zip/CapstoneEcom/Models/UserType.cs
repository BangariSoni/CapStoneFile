﻿namespace CapstoneEcom.Models
{
    public enum UserType
    {
        USER,
        ADMIN
    }
}
