﻿

namespace CapstoneEcom.Models
{
    public class Order
    {
       
        public int Id { get; set; }
        public User User { get; set; } = new User();
        public cart Cart { get; set; } = new cart();
        public Payment Payment { get; set; } = new Payment();
        public string CreatedAt { get; set; } = string.Empty;
    }
}
