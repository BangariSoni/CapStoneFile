﻿

namespace CapstoneEcom.Models
{
    public class cartItem
    {
      
        public int Id { get; set; }
        public product Product { get; set; } = new product();
    }
}
