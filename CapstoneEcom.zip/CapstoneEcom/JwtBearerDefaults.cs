﻿using Microsoft.AspNetCore.Authentication;

internal class JwtBearerDefaults
{
    internal static void AuthenticationScheme(AuthenticationOptions options)
    {
    }
}